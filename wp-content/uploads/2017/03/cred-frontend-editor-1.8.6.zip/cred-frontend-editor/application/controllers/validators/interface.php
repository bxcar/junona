<?php
interface ICRED_Validator {
    public function validate();
}