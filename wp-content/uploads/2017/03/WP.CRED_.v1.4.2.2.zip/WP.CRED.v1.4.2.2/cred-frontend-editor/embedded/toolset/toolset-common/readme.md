# Toolset Common

A collection of php, javascript and CSS libraries, utilities and models to be used with Toolsets plugins.

## Install:

Fetch the toolset-common library using composer:

		composer install --no-autoloader