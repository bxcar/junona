This directory contains dummy localization files used to produce the actual translations.
Place all localization files on parent directory.